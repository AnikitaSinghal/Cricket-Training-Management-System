﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace cricket_programme
{
    public partial class Diet_plan : Form
    {
        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString); // This is connection String
        public Diet_plan()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int a = 0;
            con1.Open();
            SqlCommand cmd2 = new SqlCommand("Select max(diet_plan_id) from diet_plan", con1); // Select query

            SqlDataReader dr2 = cmd2.ExecuteReader();

            while (dr2.Read())
            {
                a = Int32.Parse(dr2[0].ToString());

            }
            a = a + 1;
            textBox1.Text = a.ToString();
            con1.Close();
            {
                con1.Open();
                SqlCommand cmd1 = new SqlCommand("Select * from diet_plan", con1); // Select query
                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {
                    comboBox1.Items.Add(dr1[0].ToString());

                }
                con1.Close();
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con1.Open();
            SqlCommand cmd1 = new SqlCommand("Select * from diet_plan where diet_plan_id=@a", con1); // Select query
            cmd1.Parameters.AddWithValue("@a", comboBox1.Text);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                textBox1.Text = dr1[0].ToString();
                textBox2.Text = dr1[1].ToString();
                textBox3.Text = dr1[2].ToString();
                textBox4.Text = dr1[3].ToString();
                textBox5.Text = dr1[4].ToString();
            }
            con1.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            con1.Close();
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
                MessageBox.Show("Fill the data", "Msg");
            {
                try
                {

                    con1.Open();
                    SqlCommand cmd = new SqlCommand("insert into diet_plan values(@a,@b,@c,@d,@e)", con1); // insert query
                    cmd.Parameters.AddWithValue("@a", textBox1.Text);
                    cmd.Parameters.AddWithValue("@b", textBox2.Text);
                    cmd.Parameters.AddWithValue("@c", textBox3.Text);
                    cmd.Parameters.AddWithValue("@d", textBox4.Text);
                    cmd.Parameters.AddWithValue("@e", textBox5.Text);


                    SqlDataReader dr = cmd.ExecuteReader();
                    MessageBox.Show("Record Added", "Msg");
                    con1.Close();
                }
                catch (Exception ee)
                {
                    MessageBox.Show("Exception Error" + ee.ToString());
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            con1.Open();
            SqlCommand cmd = new SqlCommand("update diet_plan set breakfast=@a, Lunch=@b, eve_meal=@c, post_training=@d where diet_plan_id=@k", con1); // update query
            cmd.Parameters.AddWithValue("@k", comboBox1.Text);

            cmd.Parameters.AddWithValue("@a", textBox2.Text);
            cmd.Parameters.AddWithValue("@b", textBox3.Text);
            cmd.Parameters.AddWithValue("@c", textBox4.Text);
            cmd.Parameters.AddWithValue("@d", textBox5.Text);
            SqlDataReader dr = cmd.ExecuteReader();

            MessageBox.Show("Record Has been Updated", "Updated");
            con1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace cricket_programme
{
    public partial class attendance_performance : Form
    {
        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString); // This is connection Stri

        public attendance_performance()
        {
            InitializeComponent();
        }

        private void attendance_performance_Load(object sender, EventArgs e)
        {


            {
                int a = 0;
                con1.Open();
                SqlCommand cmd2 = new SqlCommand("Select max(attd_id) from attendance_performance", con1); // Select query

                SqlDataReader dr2 = cmd2.ExecuteReader();

                while (dr2.Read())
                {
                    a = Int32.Parse(dr2[0].ToString());

                }
                a = a + 1;
                textBox1.Text = a.ToString();
                con1.Close();
            }

            con1.Open();
            SqlCommand cmd1 = new SqlCommand("Select * from training_programme", con1); // Select query
            SqlDataReader dr1 = cmd1.ExecuteReader();

            while (dr1.Read())
            {
                comboBox1.Items.Add(dr1[0].ToString());

            }
            con1.Close();
            {
                con1.Open();
                SqlCommand cmd2 = new SqlCommand("Select * from team_member", con1); // Select query
                SqlDataReader dr2 = cmd2.ExecuteReader();

                while (dr2.Read())
                {
                    comboBox2.Items.Add(dr2[0].ToString());

                }
                con1.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                con1.Open();
                SqlCommand cmd = new SqlCommand("insert into attendance_performance values(@a,@b,@c,@d,@e)", con1); // Select query
                cmd.Parameters.AddWithValue("@a", textBox1.Text);
                cmd.Parameters.AddWithValue("@b", comboBox1.Text);
                cmd.Parameters.AddWithValue("@c", comboBox2.Text);
                cmd.Parameters.AddWithValue("@d", comboBox3.Text);
                cmd.Parameters.AddWithValue("@e", comboBox4.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("Record Added", "Msg");
                con1.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Exception Error" + ee.ToString());
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace cricket_programme
{
    public partial class training_prg : Form
    {
        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString); // This is connection Stri
        public training_prg()
        {
            InitializeComponent();
        }

        private void training_prg_Load(object sender, EventArgs e)
        {
            int a = 0;
            con1.Open();
            SqlCommand cmd2 = new SqlCommand("Select max(prg_id) from training_programme", con1); // Select query

            SqlDataReader dr2 = cmd2.ExecuteReader();

            while (dr2.Read())
            {
                a = Int32.Parse(dr2[0].ToString());

            }
            a = a + 1;
            textBox1.Text = a.ToString();
            con1.Close();
            {
                con1.Open();
                SqlCommand cmd1 = new SqlCommand("Select * from team", con1); // Select query
                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {
                    comboBox1.Items.Add(dr1[0].ToString());

                }
                con1.Close();
            }
            con1.Close();
            {
                con1.Open();
                SqlCommand cmd1 = new SqlCommand("Select * from training_programme", con1); // Select query
                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {
                    comboBox2.Items.Add(dr1[0].ToString());

                }
                con1.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                con1.Open();
                SqlCommand cmd = new SqlCommand("insert into training_programme values(@a,@b,@c,@d,@e)", con1); // insert query
                cmd.Parameters.AddWithValue("@a", textBox1.Text);
                cmd.Parameters.AddWithValue("@b", comboBox1.Text);
                cmd.Parameters.AddWithValue("@c", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@d", dateTimePicker2.Value);
                cmd.Parameters.AddWithValue("@e", textBox4.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                MessageBox.Show("Record Added", "Msg");
                con1.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Exception Error" + ee.ToString());
            }
            this.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            con1.Open();
            SqlCommand cmd1 = new SqlCommand("Select * from training_programme where prg_id=@a", con1); // Select query
            cmd1.Parameters.AddWithValue("@a", comboBox2.Text);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                textBox1.Text = dr1[0].ToString();
                comboBox1.Text = dr1[1].ToString();

                textBox4.Text = dr1[4].ToString();
            }
            con1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con1.Open();
            SqlCommand cmd = new SqlCommand("update training_programme set team_id=@a, tdate=@b, time=@c, excercise_details=@d where prg_id=@k", con1); // Update query
            cmd.Parameters.AddWithValue("@k", comboBox2.Text);

            cmd.Parameters.AddWithValue("@a", comboBox1.Text);
            cmd.Parameters.AddWithValue("@b", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@c", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@d", textBox4.Text);
            SqlDataReader dr = cmd.ExecuteReader();

            MessageBox.Show("Record Has been Updated", "Updated");
            con1.Close();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

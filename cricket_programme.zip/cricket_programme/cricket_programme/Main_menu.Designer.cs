﻿namespace cricket_programme
{
    partial class Main_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.teamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dietPlanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamMemberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trainingProgrammeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendancePerformanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.teamToolStripMenuItem,
            this.dietPlanToolStripMenuItem,
            this.teamMemberToolStripMenuItem,
            this.trainingProgrammeToolStripMenuItem,
            this.attendancePerformanceToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(371, 764);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // teamToolStripMenuItem
            // 
            this.teamToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.teamToolStripMenuItem.Name = "teamToolStripMenuItem";
            this.teamToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.teamToolStripMenuItem.Text = "Team";
            this.teamToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.teamToolStripMenuItem.Click += new System.EventHandler(this.teamToolStripMenuItem_Click);
            // 
            // dietPlanToolStripMenuItem
            // 
            this.dietPlanToolStripMenuItem.Name = "dietPlanToolStripMenuItem";
            this.dietPlanToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.dietPlanToolStripMenuItem.Text = "Diet Plan";
            this.dietPlanToolStripMenuItem.Click += new System.EventHandler(this.dietPlanToolStripMenuItem_Click);
            // 
            // teamMemberToolStripMenuItem
            // 
            this.teamMemberToolStripMenuItem.Name = "teamMemberToolStripMenuItem";
            this.teamMemberToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.teamMemberToolStripMenuItem.Text = "Team Member";
            this.teamMemberToolStripMenuItem.Click += new System.EventHandler(this.teamMemberToolStripMenuItem_Click);
            // 
            // trainingProgrammeToolStripMenuItem
            // 
            this.trainingProgrammeToolStripMenuItem.Name = "trainingProgrammeToolStripMenuItem";
            this.trainingProgrammeToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.trainingProgrammeToolStripMenuItem.Text = "Training Programme";
            this.trainingProgrammeToolStripMenuItem.Click += new System.EventHandler(this.trainingProgrammeToolStripMenuItem_Click);
            // 
            // attendancePerformanceToolStripMenuItem
            // 
            this.attendancePerformanceToolStripMenuItem.Name = "attendancePerformanceToolStripMenuItem";
            this.attendancePerformanceToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.attendancePerformanceToolStripMenuItem.Text = "Attendance && Performance";
            this.attendancePerformanceToolStripMenuItem.Click += new System.EventHandler(this.attendancePerformanceToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(364, 39);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Main_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1230, 764);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main_menu";
            this.Text = "Main Menu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem teamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dietPlanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamMemberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trainingProgrammeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attendancePerformanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}
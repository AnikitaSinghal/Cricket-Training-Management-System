﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cricket_programme
{
    public partial class Main_menu : Form
    {
        public Main_menu()
        {
            InitializeComponent();
        }

     
        private void teamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Team tt = new Team();
            tt.Show();
            tt.MdiParent = this;
        }

        private void dietPlanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Diet_plan dp = new Diet_plan();
            dp.Show();
            dp.MdiParent = this;
        }

        private void teamMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Team_Member tm = new Team_Member();
            tm.Show();
            tm.MdiParent = this;
        }

        private void trainingProgrammeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            training_prg tp = new training_prg();
            tp.Show();
            tp.MdiParent = this;
        }

        private void attendancePerformanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            attendance_performance ap = new attendance_performance();
            ap.Show();
            ap.MdiParent = this;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Main_menu_Load(object sender, EventArgs e)
        {

        }
    }
}
